# Electric Vehicle Range Analysis and Prediction

**SI Lab Project | Ramdeobaba University, Nagpur**  
**Department of Computer Science and Engineering**  
**B.Tech. CSE (Artificial Intelligence and Data Science) | Semester V | 2026–27**  
**Student:** Varad Kawtikwar | **Roll No.:** 63 | **Batch:** B2-B4

## Project overview

This statistical-inference and machine-learning project studies the relationship between battery capacity, estimated European vehicle price, launch year, manufacturer and **listed EV driving range (km)**. The notebook performs data inspection/cleaning, exploratory data analysis, correlation and hypothesis tests, CLT/bootstrap simulations, and comparison of five regression models. It includes a notebook-based interactive predictor.

## Dataset and provenance

- **Source workflow:** [European Alternative Fuels Observatory (EAFO) — Available EV models](https://alternative-fuels-observatory.ec.europa.eu/markets-and-policy/market-and-consumer-insights/available-electric-vehicle-models)
- **Actual input in the saved Colab run:** uploaded file `EAFO_EV_Range_raw_sample.csv`, **49 rows × 10 input columns**
- **Cleaned output:** **49 rows × 18 columns**, spanning **25 manufacturers**
- **Collection limitation:** EAFO `robots.txt` returned HTTP 403, so the notebook **did not scrape the site live**. It used the uploaded CSV instead.
- **Data file status:** The original CSV was not attached for this repository package. See [`data/README.md`](data/README.md). No substitute dataset has been invented.
- Prices in `Price_INR` are EUR-to-INR conversions using the recorded reference rate from **2026-10-26**. These values are **not retail prices in India**.

## Statistical analysis

The saved notebook outputs include descriptive statistics, missing-value/duplicate checks, distribution plots, battery–range scatter plot, correlations, covariance, a one-sample t-test, confidence intervals, CLT and bootstrap.

| Statistic | Saved notebook output |
|---|---:|
| Mean listed range | 428.57 km |
| Median listed range | 460 km |
| Pearson battery–range correlation | 0.8520 |
| Spearman battery–range correlation | 0.8372 |
| One-sample t-test (400 km reference), p-value | 0.0194 |
| 95% t-confidence interval for mean range | 404.81–452.33 km |
| 95% bootstrap confidence interval | 405.81–450.00 km |

**Interpretation note:** These are statistical summaries of the non-random available sample, not estimates for all EVs or guarantees of real-road vehicle performance.

## Five regression models

The models use `Range_km` as target. Multiple-feature models use `Battery_kWh`, `Price_INR`, `Available_Year` and `Brand`; simple linear regression uses battery capacity only.

| Model | Training CV RMSE (km) | Test MAE (km) | Test RMSE (km) | Test R² |
|---|---:|---:|---:|---:|
| Decision Tree | 35.420 | 28.667 | 33.158 | 0.894 |
| Gradient Boosting | 38.309 | 25.076 | 30.537 | 0.910 |
| Simple Linear Regression | 41.328 | 45.714 | 49.590 | 0.763 |
| Random Forest | 41.347 | 28.045 | 33.267 | 0.893 |
| Multiple Linear Regression | 62.938 | 40.792 | 52.249 | 0.737 |

**Selected model:** Decision Tree, because it had the **lowest mean training five-fold CV RMSE (35.420 km)**. The notebook chose this before reporting its held-out test scores. Although Gradient Boosting had better test RMSE and R² on this split, selecting by test scores would change the stated evaluation methodology. The saved-model reload check **passed** in the Colab run.

## Visual results

![Battery versus range scatter plot](figures/battery_range_scatter.png)

![Five-model comparison](figures/model_comparison_cv_rmse.png)

Additional verified plots are in [`figures/`](figures/): range distribution, box plot, manufacturer distribution, correlation heatmap, CLT, bootstrap, actual vs predicted and residual analysis.

## Run in Google Colab

1. Open [`EV_Range_Analysis.ipynb`](EV_Range_Analysis.ipynb) in [Google Colab](https://colab.research.google.com/).
2. In the dataset-acquisition cell set `DATA_SOURCE_MODE = 'upload'` (or specify an existing genuine CSV via `INPUT_FILE_PATH`).
3. Choose your actual EV CSV file when prompted. Do **not** wait indefinitely for blocked live access.
4. Run the remaining cells. They generate cleaning outputs, statistics, figures, five-model comparison and the interactive prediction form.
5. From the final cell, download the runtime-generated `EV_Range_Project.zip` if you want to keep the cleaned CSV, evaluation tables and saved model artifact produced in *your own* run.

The notebook installs its dependencies; the same package set is listed in [`requirements.txt`](requirements.txt). Notebook screenshots/outputs are **from the supplied completed run**, but a fresh session requires the genuine input dataset.

## Repository contents

- `EV_Range_Analysis.ipynb` — final notebook with actual saved outputs.
- `figures/` — selected actual project graphs.
- `results/model_comparison_saved_output.csv` — model metrics **transcribed from displayed saved notebook output (rounded)**.
- `data/README.md` — dataset provenance and missing-file note.
- `requirements.txt` — package list from the notebook.

The trained `.joblib` artifact and original 49-record CSV are **not** included because those files were not provided separately. They may be uploaded later from the actual Colab project export. Never upload passwords, API keys or other secrets.

## References

- [EAFO — Available Electric Vehicle Models](https://alternative-fuels-observatory.ec.europa.eu/markets-and-policy/market-and-consumer-insights/available-electric-vehicle-models)
- [pandas documentation](https://pandas.pydata.org/docs/)
- [SciPy documentation](https://docs.scipy.org/doc/scipy/reference/stats.html)
- [scikit-learn documentation](https://scikit-learn.org/stable/)
- [Matplotlib documentation](https://matplotlib.org/stable/)
- [Seaborn documentation](https://seaborn.pydata.org/)
