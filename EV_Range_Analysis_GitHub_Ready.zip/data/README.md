# Dataset

The executed notebook loaded a user-provided EAFO CSV export named `EAFO_EV_Range_raw_sample.csv` containing **49 EV records**. The actual CSV file was **not included among the source files attached for repository preparation**. This folder does not contain replacement or synthetic EV data.

To rerun the notebook, supply your authentic saved CSV or another permitted EAFO export using the notebook upload prompt (`DATA_SOURCE_MODE = 'upload'`). The notebook validates the schema and creates a cleaned dataset and derived results.

Only add the original CSV to a public repository if its sharing terms allow it. The EV catalogue information is European-market oriented; the displayed INR prices are approximations converted from EUR, not Indian vehicle selling prices.

Source project website: https://alternative-fuels-observatory.ec.europa.eu/markets-and-policy/market-and-consumer-insights/available-electric-vehicle-models
